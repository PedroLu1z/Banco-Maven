package Dominio;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class App {
	public static void main(String[] args) {
		
		Conta c1 = new Conta(new IdConta("123", "456"),"Pedro Luiz", 18, "pedrolui@gmail.com", "121212", 1500);
		System.out.println(c1.toString());
		
		Conta c2 = new Conta();
		IdConta I1 = new IdConta();
		I1.setCpf("789");
		I1.setRg("012");
		c2.setId(I1);
		c2.setNome("Bruno Caputo");
		c2.setIdade(19);
		c2.setEmail("caputo@gmail.com");
		c2.setNumeroConta("95");
		c2.setSaldo(1200);
		
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("bancoDoBrasil");
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		
		em.persist(c1);
		em.persist(c2);
		
		em.getTransaction().commit();
		System.out.println("Pronto!");
		em.close();
		emf.close();
	}
}
